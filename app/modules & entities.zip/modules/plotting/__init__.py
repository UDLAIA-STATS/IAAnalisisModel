from .diagram_processor import generate_diagrams
