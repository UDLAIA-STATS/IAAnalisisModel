import pathlib
from typing import Generator, List

import cv2
from cv2.typing import MatLike


def read_video(video_path: str, target_width: int = 640, sample_rate=1) -> Generator[tuple[MatLike, float]]:
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        raise FileNotFoundError(f"No se pudo abrir el video: {video_path}")
    
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_count = 0
    dt = 1.0 / fps

    frames = []
    while True:
        ret, frame = cap.read()
        if not ret or not frame:
            break
        
        frame_count += 1
        if sample_rate > 1 and (frame_count % sample_rate) != 0:
            continue
        
        h, w = frame.shape[:2]
        if w != target_width:
            scale = target_width / float(w)
            new_h = int(h * scale)
            frame = cv2.resize(frame, (target_width, new_h))
        yield frame, dt 

    cap.release()

    
def extract_player_images(
    video_frames: List[MatLike],
    tracks_collection,
    output_folder: str
):
    folder = pathlib.Path(output_folder)
    folder.mkdir(parents=True, exist_ok=True)

    saved_ids = set() 

    for frame_num, player_track in tracks_collection.tracks["players"].items():
        for player_id, track in player_track.items():
            if player_id in saved_ids:
                continue

            bbox = track.bbox
            if bbox is None or len(bbox) != 4:
                continue  # Evita errores si el bbox no es válido

            x1, y1, x2, y2 = map(int, bbox)

            # Validación de límites dentro del frame
            frame = video_frames[int(frame_num)]
            h, w = frame.shape[:2]
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w, x2), min(h, y2)
            if x2 <= x1 or y2 <= y1:
                continue  # Bounding box inválido

            # Recorte del jugador
            player_image = frame[y1:y2, x1:x2]

            # Guardar imagen
            player_image_path = folder / f"player_{player_id}_frame_{frame_num}.png"
            cv2.imwrite(str(player_image_path), player_image)

            # Marcar este track_id como ya guardado
            saved_ids.add(player_id)
